// Role card highlight + password show/hide + delete confirm
document.addEventListener('click', e=>{
  const t = e.target.closest('[data-toggle-pw]');
  if (t){
    const inp = document.querySelector(t.dataset.target);
    if (inp){ inp.type = inp.type==='password'?'text':'password';
      t.innerHTML = inp.type==='password'?'<i class="bi bi-eye"></i>':'<i class="bi bi-eye-slash"></i>'; }
  }
  const d = e.target.closest('[data-confirm]');
  if (d && !confirm(d.dataset.confirm)) e.preventDefault();
});
document.querySelectorAll('.role-grid input').forEach(r=>{
  r.addEventListener('change',()=>{
    document.querySelectorAll('.role-card').forEach(c=>c.classList.remove('is-selected'));
    r.closest('.role-card').classList.add('is-selected');
  });
  if (r.checked) r.closest('.role-card').classList.add('is-selected');
});
