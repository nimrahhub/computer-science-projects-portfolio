<?php
require_once 'includes/config.php';
if (!empty($_SESSION['user'])) { header('Location: dashboard.php'); exit; }
$err=flash('error'); $ok=flash('success');
if ($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $name=trim($_POST['full_name']??''); $email=trim($_POST['email']??'');
  $badge=trim($_POST['badge_no']??''); $phone=trim($_POST['phone']??'');
  $role=$_POST['role']??'officer'; $pw=$_POST['password']??''; $pw2=$_POST['password2']??'';
  if (!$name||!$email||!$pw) flash('error','Please fill all required fields.');
  elseif (strlen($pw)<6) flash('error','Password must be at least 6 characters.');
  elseif ($pw!==$pw2) flash('error','Passwords do not match.');
  elseif (!in_array($role,['admin','officer','clerk'])) flash('error','Invalid role.');
  else {
    try{
      $stmt=$pdo->prepare('INSERT INTO users(full_name,email,badge_no,phone,role,password_hash) VALUES(?,?,?,?,?,?)');
      $stmt->execute([$name,$email,$badge?:null,$phone?:null,$role,password_hash($pw,PASSWORD_DEFAULT)]);
      flash('success','Account created. You can sign in now.');
      header('Location: login.php'); exit;
    }catch(PDOException $e){
      flash('error', str_contains($e->getMessage(),'Duplicate')?'Email already registered.':'Signup failed.');
    }
  }
  header('Location: signup.php'); exit;
}
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sign up - <?= APP_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head><body>
<div class="auth-wrap">
  <aside class="auth-art">
    <div class="auth-brand">
      <div class="logo"><i class="bi bi-shield-fill-check"></i></div>
      <span>Pak<b>Traffic</b></span>
    </div>
    <div class="auth-hero">
      <h1>Join the <em>traffic</em> team.<br>Issue your first challan today.</h1>
      <p>Create your PakTraffic TVMS account and get instant access to the challan dashboard, driver registry and ticketing tools.</p>
      <div class="auth-stats">
        <div class="stat"><b>3</b><span>Roles</span></div>
        <div class="stat"><b>Realtime</b><span>Sync</span></div>
        <div class="stat"><b>Secure</b><span>bcrypt + CSRF</span></div>
      </div>
    </div>
    <div style="opacity:.7;font-size:12px;position:relative;z-index:2">&copy; <?= date('Y') ?> PakTraffic TVMS</div>
  </aside>
  <section class="auth-card-wrap">
    <div class="auth-card fade-up">
      <h2>Create account</h2>
      <p class="lead">It only takes a minute.</p>
      <?php if($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>
      <?php if($ok): ?><div class="alert alert-success py-2"><?= e($ok) ?></div><?php endif; ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">

        <label class="form-label">I am signing up as</label>
        <div class="role-grid mb-3">
          <label class="role-card"><input type="radio" name="role" value="admin"><i class="bi bi-shield-lock"></i><b>Admin</b><small>Manages all</small></label>
          <label class="role-card"><input type="radio" name="role" value="officer" checked><i class="bi bi-person-badge"></i><b>Officer</b><small>Issues tickets</small></label>
          <label class="role-card"><input type="radio" name="role" value="clerk"><i class="bi bi-journal-text"></i><b>Clerk</b><small>Office staff</small></label>
        </div>

        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Full name</label>
            <div class="input-with-icon"><i class="bi bi-person"></i>
              <input class="form-control" name="full_name" required></div>
          </div>
          <div class="col-md-6">
            <label class="form-label">Badge / ID</label>
            <div class="input-with-icon"><i class="bi bi-hash"></i>
              <input class="form-control" name="badge_no" placeholder="LTP-1234"></div>
          </div>
          <div class="col-md-7">
            <label class="form-label">Email</label>
            <div class="input-with-icon"><i class="bi bi-envelope"></i>
              <input class="form-control" type="email" name="email" required></div>
          </div>
          <div class="col-md-5">
            <label class="form-label">Phone</label>
            <div class="input-with-icon"><i class="bi bi-telephone"></i>
              <input class="form-control" name="phone"></div>
          </div>
          <div class="col-md-6">
            <label class="form-label">Password</label>
            <div class="input-with-icon"><i class="bi bi-lock"></i>
              <input class="form-control" type="password" id="pw1" name="password" required>
              <button type="button" class="btn btn-link position-absolute" style="right:4px;top:4px;color:var(--muted)" data-toggle-pw data-target="#pw1"><i class="bi bi-eye"></i></button></div>
          </div>
          <div class="col-md-6">
            <label class="form-label">Confirm</label>
            <div class="input-with-icon"><i class="bi bi-lock-fill"></i>
              <input class="form-control" type="password" name="password2" required></div>
          </div>
        </div>
        <button class="btn btn-grad mt-4"><i class="bi bi-person-plus"></i> Create account</button>
      </form>
      <div class="auth-foot">Already have one? <a href="login.php">Sign in</a></div>
    </div>
  </section>
</div>
<script src="assets/js/app.js"></script>
</body></html>
