<?php
$title='New violation'; require_once 'includes/header.php';
$types=['Over Speeding','Signal Violation','Illegal Parking','One Way Violation','No Helmet','Mobile Phone Use','No Fitness Certificate','Reckless Driving','Wrong Way','Expired Driving License'];

if ($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $ticket = $_POST['ticket_no'] ?: ('PKT-'.strtoupper(bin2hex(random_bytes(3))));
  try {
    $stmt = $pdo->prepare('INSERT INTO violations(ticket_no,plate_no,driver_name,license_no,violation_type,location,fine_amount,status,notes,officer_id,violation_date) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
    $stmt->execute([
      $ticket, strtoupper(trim($_POST['plate_no'])), trim($_POST['driver_name']), trim($_POST['license_no']),
      $_POST['violation_type'], trim($_POST['location']), (float)$_POST['fine_amount'],
      $_POST['status'] ?: 'pending', trim($_POST['notes']), $_SESSION['user']['id'],
      $_POST['violation_date'] ?: date('Y-m-d H:i:s')
    ]);
    flash('success',"Ticket {$ticket} issued.");
    header('Location: violations.php'); exit;
  } catch(PDOException $e){ flash('error','Could not save: '.$e->getMessage()); }
}
?>
<div class="panel fade-up" style="max-width:900px;margin:0 auto">
  <h5><i class="bi bi-plus-circle"></i> Issue new challan</h5>
  <form method="post" class="row g-3">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <div class="col-md-4"><label class="form-label">Ticket No (auto)</label>
      <input class="form-control" name="ticket_no" placeholder="Auto-generated"></div>
    <div class="col-md-4"><label class="form-label">Plate Number *</label>
      <input class="form-control" name="plate_no" required placeholder="LEA-1234"></div>
    <div class="col-md-4"><label class="form-label">Date / time *</label>
      <input class="form-control" type="datetime-local" name="violation_date" value="<?= date('Y-m-d\TH:i') ?>" required></div>

    <div class="col-md-6"><label class="form-label">Driver name</label>
      <input class="form-control" name="driver_name" placeholder="Ahmed Khan"></div>
    <div class="col-md-6"><label class="form-label">License number</label>
      <input class="form-control" name="license_no" placeholder="LHR-2024-9981"></div>

    <div class="col-md-6"><label class="form-label">Violation type *</label>
      <select class="form-select" name="violation_type" required>
        <option value="">Select...</option>
        <?php foreach($types as $t): ?><option><?= $t ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-3"><label class="form-label">Fine amount (Rs.) *</label>
      <input class="form-control" type="number" step="0.01" min="0" name="fine_amount" value="2000" required></div>
    <div class="col-md-3"><label class="form-label">Status</label>
      <select class="form-select" name="status">
        <?php foreach(['pending','paid','contested','cancelled'] as $s): ?><option><?= $s ?></option><?php endforeach; ?>
      </select></div>

    <div class="col-12"><label class="form-label">Location</label>
      <input class="form-control" name="location" placeholder="Mall Road, Lahore"></div>
    <div class="col-12"><label class="form-label">Notes</label>
      <textarea class="form-control" name="notes" rows="3" placeholder="Additional remarks..."></textarea></div>

    <div class="col-12 d-flex gap-2">
      <button class="btn btn-primary"><i class="bi bi-check2-circle"></i> Save ticket</button>
      <a href="violations.php" class="btn btn-outline-light">Cancel</a>
    </div>
  </form>
</div>
<?php require 'includes/footer.php'; ?>
