<?php
$title='Officers'; require_once 'includes/header.php'; require_role('admin');
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='delete'){
  csrf_check();
  if ((int)$_POST['id']!==(int)$_SESSION['user']['id'])
    $pdo->prepare('DELETE FROM users WHERE id=?')->execute([(int)$_POST['id']]);
  flash('success','User removed.'); header('Location: users.php'); exit;
}
$rows=$pdo->query('SELECT id,full_name,email,badge_no,phone,role,created_at FROM users ORDER BY id DESC')->fetchAll();
?>
<div class="panel fade-up">
  <h5><i class="bi bi-people"></i> Officers & staff</h5>
  <div class="table-responsive">
    <table class="table">
      <thead><tr><th>Name</th><th>Email</th><th>Badge</th><th>Role</th><th>Joined</th><th></th></tr></thead>
      <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><?= e($r['full_name']) ?></td>
          <td><?= e($r['email']) ?></td>
          <td><?= e($r['badge_no']) ?></td>
          <td><span class="badge role-<?= e($r['role']) ?>"><?= strtoupper(e($r['role'])) ?></span></td>
          <td><?= e(date('M d, Y',strtotime($r['created_at']))) ?></td>
          <td class="text-end">
            <?php if($r['id']!=$_SESSION['user']['id']): ?>
            <form method="post" class="d-inline">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <button class="btn btn-sm btn-danger" data-confirm="Delete <?= e($r['full_name']) ?>?"><i class="bi bi-trash"></i></button>
            </form>
            <?php else: ?><span class="text-muted small">you</span><?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require 'includes/footer.php'; ?>
