<?php
$title='Drivers'; require_once 'includes/header.php';
if ($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  if (($_POST['action']??'')==='add'){
    try{
      $pdo->prepare('INSERT INTO drivers(license_no,full_name,phone,address) VALUES(?,?,?,?)')->execute([
        trim($_POST['license_no']),trim($_POST['full_name']),trim($_POST['phone']),trim($_POST['address'])]);
      flash('success','Driver added.');
    }catch(PDOException $e){ flash('error','Driver exists or invalid.'); }
  } elseif (($_POST['action']??'')==='delete'){
    $pdo->prepare('DELETE FROM drivers WHERE id=?')->execute([(int)$_POST['id']]);
    flash('success','Driver removed.');
  }
  header('Location: drivers.php'); exit;
}
$rows=$pdo->query('SELECT * FROM drivers ORDER BY id DESC')->fetchAll();
?>
<div class="row g-3 fade-up">
  <div class="col-lg-4">
    <div class="panel">
      <h5><i class="bi bi-person-plus"></i> Add driver</h5>
      <form method="post" class="d-grid gap-2">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="add">
        <input class="form-control" name="license_no" placeholder="LHR-2024-9981 *" required>
        <input class="form-control" name="full_name" placeholder="Ahmed Khan *" required>
        <input class="form-control" name="phone" placeholder="0300-1234567">
        <input class="form-control" name="address" placeholder="Gulberg, Lahore">
        <button class="btn btn-primary"><i class="bi bi-check2"></i> Save</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="panel">
      <h5><i class="bi bi-person-vcard"></i> Driver registry</h5>
      <div class="table-responsive">
        <table class="table">
          <thead><tr><th>License</th><th>Name</th><th>Phone</th><th>Address</th><th></th></tr></thead>
          <tbody>
          <?php foreach($rows as $r): ?>
            <tr><td><b><?= e($r['license_no']) ?></b></td><td><?= e($r['full_name']) ?></td>
              <td><?= e($r['phone']) ?></td><td class="text-muted"><?= e($r['address']) ?></td>
              <td class="text-end">
                <form method="post" class="d-inline">
                  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= $r['id'] ?>">
                  <button class="btn btn-sm btn-danger" data-confirm="Delete this driver?"><i class="bi bi-trash"></i></button>
                </form>
              </td></tr>
          <?php endforeach; if(!$rows): ?><tr><td colspan="5" class="text-center text-muted py-3">No drivers yet.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require 'includes/footer.php'; ?>
