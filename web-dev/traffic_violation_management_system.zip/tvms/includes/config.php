<?php
// Database config - edit if your XAMPP credentials differ
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'tvms');

define('APP_NAME', 'PakTraffic TVMS');
define('APP_TAGLINE', 'Pakistan Traffic Violation Management System');

if (session_status() === PHP_SESSION_NONE) session_start();

try {
  $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch (PDOException $e) {
  die('<div style="font-family:sans-serif;padding:40px;color:#b00">DB connection failed: '.htmlspecialchars($e->getMessage()).'<br>Make sure XAMPP MySQL is running and you imported <code>database.sql</code>.</div>');
}

function e($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function money($amount){ return 'Rs. '.number_format((float)$amount, 2); }
function require_login(){
  if (empty($_SESSION['user'])) { header('Location: login.php'); exit; }
}
function require_role($roles){
  require_login();
  if (!in_array($_SESSION['user']['role'], (array)$roles)) {
    http_response_code(403); die('Forbidden');
  }
}
function flash($k, $v=null){
  if ($v===null){ $x=$_SESSION['flash'][$k]??null; unset($_SESSION['flash'][$k]); return $x; }
  $_SESSION['flash'][$k]=$v;
}
function csrf_token(){
  if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(16));
  return $_SESSION['csrf'];
}
function csrf_check(){
  if (!hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')) { http_response_code(400); die('Bad CSRF'); }
}
