<?php require_once __DIR__.'/config.php'; require_login(); ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title ?? APP_NAME) ?> - <?= APP_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head>
<body class="app-shell">
<nav class="navbar navbar-expand-lg app-nav sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand brand" href="dashboard.php">
      <span class="brand-mark"><i class="bi bi-shield-fill-check"></i></span>
      <span class="brand-text">Pak<span>Traffic</span></span>
    </a>
    <button class="navbar-toggler text-light" data-bs-toggle="collapse" data-bs-target="#nv"><i class="bi bi-list"></i></button>
    <div class="collapse navbar-collapse" id="nv">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="violations.php"><i class="bi bi-cone-striped"></i> Violations</a></li>
        <li class="nav-item"><a class="nav-link" href="add_violation.php"><i class="bi bi-plus-circle"></i> New Ticket</a></li>
        <li class="nav-item"><a class="nav-link" href="drivers.php"><i class="bi bi-person-vcard"></i> Drivers</a></li>
        <?php if(($_SESSION['user']['role']??'')==='admin'): ?>
        <li class="nav-item"><a class="nav-link" href="users.php"><i class="bi bi-people"></i> Officers</a></li>
        <?php endif; ?>
      </ul>
      <div class="d-flex align-items-center gap-3">
        <span class="user-chip">
          <i class="bi bi-person-circle"></i>
          <span><?= e($_SESSION['user']['full_name']) ?></span>
          <span class="badge role-<?= e($_SESSION['user']['role']) ?>"><?= strtoupper(e($_SESSION['user']['role'])) ?></span>
        </span>
        <a href="logout.php" class="btn btn-sm btn-outline-light"><i class="bi bi-box-arrow-right"></i> Logout</a>
      </div>
    </div>
  </div>
</nav>
<main class="container-fluid py-4">
<?php if($m=flash('success')): ?><div class="alert alert-success"><i class="bi bi-check-circle"></i> <?= e($m) ?></div><?php endif; ?>
<?php if($m=flash('error')): ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle"></i> <?= e($m) ?></div><?php endif; ?>
