</main>
<footer class="app-footer">
  <div class="container-fluid d-flex justify-content-between">
    <span>&copy; <?= date('Y') ?> PakTraffic TVMS</span>
    <span>Built with PHP, MySQL, Bootstrap</span>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>
</body></html>
