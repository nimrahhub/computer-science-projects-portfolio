<?php
$title='Dashboard'; require_once 'includes/header.php';
$total = $pdo->query('SELECT COUNT(*) c FROM violations')->fetch()['c'];
$pending = $pdo->query("SELECT COUNT(*) c FROM violations WHERE status='pending'")->fetch()['c'];
$paid = $pdo->query("SELECT COUNT(*) c FROM violations WHERE status='paid'")->fetch()['c'];
$revenue = $pdo->query("SELECT COALESCE(SUM(fine_amount),0) s FROM violations WHERE status='paid'")->fetch()['s'];
$recent = $pdo->query('SELECT * FROM violations ORDER BY id DESC LIMIT 6')->fetchAll();
?>
<div class="row g-3 fade-up">
  <div class="col-md-3"><div class="kpi"><div class="icon"><i class="bi bi-cone-striped"></i></div><div class="label">Total Violations</div><div class="value"><?= $total ?></div></div></div>
  <div class="col-md-3"><div class="kpi red"><div class="icon"><i class="bi bi-hourglass-split"></i></div><div class="label">Pending</div><div class="value"><?= $pending ?></div></div></div>
  <div class="col-md-3"><div class="kpi green"><div class="icon"><i class="bi bi-cash-coin"></i></div><div class="label">Paid Tickets</div><div class="value"><?= $paid ?></div></div></div>
  <div class="col-md-3"><div class="kpi blue"><div class="icon"><i class="bi bi-graph-up"></i></div><div class="label">Revenue Collected</div><div class="value"><?= money($revenue) ?></div></div></div>
</div>

<div class="row g-3 mt-1">
  <div class="col-lg-8">
    <div class="panel">
      <h5><i class="bi bi-clock-history"></i> Recent challans <a href="violations.php" class="ms-auto small text-info">View all &rarr;</a></h5>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Ticket</th><th>Plate</th><th>Type</th><th>Fine</th><th>Status</th><th>Date</th></tr></thead>
          <tbody>
          <?php foreach($recent as $r): ?>
            <tr>
              <td><b><?= e($r['ticket_no']) ?></b></td>
              <td><?= e($r['plate_no']) ?></td>
              <td><?= e($r['violation_type']) ?></td>
              <td><?= money($r['fine_amount']) ?></td>
              <td><span class="status <?= e($r['status']) ?>"><?= e($r['status']) ?></span></td>
              <td><?= e(date('M d, Y', strtotime($r['violation_date']))) ?></td>
            </tr>
          <?php endforeach; if(!$recent): ?><tr><td colspan="6" class="text-center text-muted py-4">No violations yet.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="panel">
      <h5><i class="bi bi-lightning-charge"></i> Quick actions</h5>
      <div class="d-grid gap-2">
        <a href="add_violation.php" class="btn btn-primary"><i class="bi bi-plus-circle"></i> Issue new challan</a>
        <a href="violations.php" class="btn btn-outline-light"><i class="bi bi-list-task"></i> Manage violations</a>
        <a href="drivers.php" class="btn btn-outline-light"><i class="bi bi-person-vcard"></i> Driver registry</a>
      </div>
      <hr style="border-color:var(--line)">
      <div class="text-muted small">Logged in as <b class="text-light"><?= e($_SESSION['user']['full_name']) ?></b> - <?= e($_SESSION['user']['role']) ?></div>
    </div>
  </div>
</div>
<?php require 'includes/footer.php'; ?>
