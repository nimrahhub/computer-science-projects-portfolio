-- Traffic Violation Management System Database
-- Import this in phpMyAdmin (http://localhost/phpmyadmin)

CREATE DATABASE IF NOT EXISTS tvms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tvms;

-- Users (officers / admins)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  badge_no VARCHAR(50) DEFAULT NULL,
  phone VARCHAR(30) DEFAULT NULL,
  role ENUM('admin','officer','clerk') NOT NULL DEFAULT 'officer',
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Drivers
CREATE TABLE IF NOT EXISTS drivers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  license_no VARCHAR(40) NOT NULL UNIQUE,
  full_name VARCHAR(120) NOT NULL,
  phone VARCHAR(30),
  address VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Vehicles
CREATE TABLE IF NOT EXISTS vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plate_no VARCHAR(20) NOT NULL UNIQUE,
  make VARCHAR(60),
  model VARCHAR(60),
  color VARCHAR(30),
  driver_id INT,
  FOREIGN KEY (driver_id) REFERENCES drivers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Violations
CREATE TABLE IF NOT EXISTS violations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ticket_no VARCHAR(30) NOT NULL UNIQUE,
  plate_no VARCHAR(20) NOT NULL,
  driver_name VARCHAR(120),
  license_no VARCHAR(40),
  violation_type VARCHAR(80) NOT NULL,
  location VARCHAR(180),
  fine_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  status ENUM('pending','paid','contested','cancelled') NOT NULL DEFAULT 'pending',
  notes TEXT,
  officer_id INT,
  violation_date DATETIME NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (officer_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Sample users: password for all sample accounts = admin123
INSERT IGNORE INTO users (full_name, email, badge_no, phone, role, password_hash)
VALUES
('Ayesha Siddiqui', 'admin@paktraffic.local', 'ADM-PK-001', '0300-1112233', 'admin',
  '$2y$10$GQhSP.66dtkmcLPf7a/yc.1Wa3CyFQHUyyl0OyGlKG5m8CWYC9zMu'),
('Sub Inspector Bilal Ahmed', 'officer@paktraffic.local', 'LTP-2045', '0321-5557788', 'officer',
  '$2y$10$GQhSP.66dtkmcLPf7a/yc.1Wa3CyFQHUyyl0OyGlKG5m8CWYC9zMu'),
('Traffic Clerk Sana Iqbal', 'clerk@paktraffic.local', 'CLK-118', '0333-9012345', 'clerk',
  '$2y$10$GQhSP.66dtkmcLPf7a/yc.1Wa3CyFQHUyyl0OyGlKG5m8CWYC9zMu');

INSERT IGNORE INTO drivers (license_no, full_name, phone, address)
VALUES
('LHR-2024-9981', 'Ahmed Khan', '0300-1234567', 'Gulberg III, Lahore'),
('KHI-2023-7782', 'Fatima Noor', '0345-9876543', 'DHA Phase 5, Karachi'),
('ISB-2022-4410', 'Usman Ali', '0312-4567890', 'G-10 Markaz, Islamabad');

INSERT IGNORE INTO vehicles (plate_no, make, model, color, driver_id)
VALUES
('LEA-1234', 'Toyota', 'Corolla', 'White', (SELECT id FROM drivers WHERE license_no='LHR-2024-9981')),
('BFX-778', 'Honda', 'Civic', 'Black', (SELECT id FROM drivers WHERE license_no='KHI-2023-7782')),
('ICT-4410', 'Suzuki', 'Alto', 'Silver', (SELECT id FROM drivers WHERE license_no='ISB-2022-4410'));

INSERT IGNORE INTO violations (ticket_no, plate_no, driver_name, license_no, violation_type, location, fine_amount, status, officer_id, violation_date, notes)
VALUES
('PKT-1001','LEA-1234','Ahmed Khan','LHR-2024-9981','Over Speeding','Mall Road, Lahore',2500.00,'pending',(SELECT id FROM users WHERE email='officer@paktraffic.local'), NOW(), 'Speed recorded above the posted limit near Chairing Cross.'),
('PKT-1002','BFX-778','Fatima Noor','KHI-2023-7782','Signal Violation','Shahrah-e-Faisal, Karachi',3000.00,'paid',(SELECT id FROM users WHERE email='officer@paktraffic.local'), NOW(), 'Crossed red signal at main intersection.'),
('PKT-1003','ICT-4410','Usman Ali','ISB-2022-4410','Illegal Parking','Blue Area, Islamabad',1500.00,'contested',(SELECT id FROM users WHERE email='officer@paktraffic.local'), NOW(), 'Vehicle parked in a no-parking zone.');
