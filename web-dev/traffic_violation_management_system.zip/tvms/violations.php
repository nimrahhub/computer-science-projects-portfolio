<?php
$title='Violations'; require_once 'includes/header.php';

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='delete') {
  csrf_check();
  $pdo->prepare('DELETE FROM violations WHERE id=?')->execute([(int)$_POST['id']]);
  flash('success','Violation deleted.'); header('Location: violations.php'); exit;
}
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='status') {
  csrf_check();
  $pdo->prepare('UPDATE violations SET status=? WHERE id=?')->execute([$_POST['status'],(int)$_POST['id']]);
  flash('success','Status updated.'); header('Location: violations.php'); exit;
}

$q = trim($_GET['q']??''); $status=$_GET['status']??'';
$where=[]; $args=[];
if ($q){ $where[]='(ticket_no LIKE ? OR plate_no LIKE ? OR driver_name LIKE ? OR license_no LIKE ?)'; array_push($args,"%$q%","%$q%","%$q%","%$q%"); }
if ($status){ $where[]='status=?'; $args[]=$status; }
$sql='SELECT * FROM violations'.($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY id DESC';
$stmt=$pdo->prepare($sql); $stmt->execute($args); $rows=$stmt->fetchAll();
?>
<div class="panel fade-up">
  <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
    <h5 class="mb-0"><i class="bi bi-cone-striped"></i> Violations</h5>
    <form class="d-flex gap-2 ms-auto flex-wrap" method="get">
      <input class="form-control" name="q" placeholder="Search ticket / plate / driver" value="<?= e($q) ?>" style="min-width:240px">
      <select class="form-select" name="status" style="max-width:160px">
        <option value="">All status</option>
        <?php foreach(['pending','paid','contested','cancelled'] as $s): ?>
          <option <?= $status===$s?'selected':'' ?>><?= $s ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn-primary"><i class="bi bi-search"></i></button>
      <a href="add_violation.php" class="btn btn-outline-light"><i class="bi bi-plus-circle"></i> New</a>
    </form>
  </div>

  <div class="table-responsive">
    <table class="table align-middle">
      <thead><tr><th>Ticket</th><th>Plate</th><th>Driver</th><th>Violation</th><th>Location</th><th>Fine</th><th>Status</th><th>Date</th><th class="text-end">Actions</th></tr></thead>
      <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><b><?= e($r['ticket_no']) ?></b></td>
          <td><?= e($r['plate_no']) ?></td>
          <td><?= e($r['driver_name']) ?><div class="text-muted small"><?= e($r['license_no']) ?></div></td>
          <td><?= e($r['violation_type']) ?></td>
          <td class="text-muted"><?= e($r['location']) ?></td>
          <td><?= money($r['fine_amount']) ?></td>
          <td>
            <form method="post" class="d-flex gap-1">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="action" value="status">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                <?php foreach(['pending','paid','contested','cancelled'] as $s): ?>
                  <option <?= $r['status']===$s?'selected':'' ?>><?= $s ?></option>
                <?php endforeach; ?>
              </select>
            </form>
          </td>
          <td><?= e(date('M d, Y', strtotime($r['violation_date']))) ?></td>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-light" href="edit_violation.php?id=<?= $r['id'] ?>"><i class="bi bi-pencil"></i></a>
            <form method="post" class="d-inline">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <button class="btn btn-sm btn-danger" data-confirm="Delete ticket <?= e($r['ticket_no']) ?>?"><i class="bi bi-trash"></i></button>
            </form>
          </td>
        </tr>
      <?php endforeach; if(!$rows): ?><tr><td colspan="9" class="text-center text-muted py-4">No violations match your filter.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require 'includes/footer.php'; ?>
