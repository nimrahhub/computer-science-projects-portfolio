<?php
require_once 'includes/config.php';
if (!empty($_SESSION['user'])) { header('Location: dashboard.php'); exit; }
$err = flash('error');
if ($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $email = trim($_POST['email']??'');
  $pass  = $_POST['password']??'';
  $role  = $_POST['role']??'';
  $stmt = $pdo->prepare('SELECT * FROM users WHERE email=?');
  $stmt->execute([$email]);
  $u = $stmt->fetch();
  if ($u && password_verify($pass, $u['password_hash'])){
    if ($role && $role !== $u['role']){
      flash('error', "Your account role is '{$u['role']}', not '{$role}'.");
    } else {
      unset($u['password_hash']);
      $_SESSION['user']=$u;
      header('Location: dashboard.php'); exit;
    }
  } else {
    flash('error','Invalid email or password.');
  }
  header('Location: login.php'); exit;
}
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - <?= APP_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="assets/css/app.css" rel="stylesheet">
</head><body>
<div class="auth-wrap">
  <aside class="auth-art">
    <div class="auth-brand">
      <div class="logo"><i class="bi bi-shield-fill-check"></i></div>
      <span>Pak<b>Traffic</b></span>
    </div>
    <div class="auth-hero">
      <h1>Manage challans.<br>Keep <em>roads</em> moving.</h1>
      <p>PakTraffic TVMS helps traffic police officers, clerks and administrators issue challans, track fines and manage driver records across Pakistan.</p>
      <div class="auth-stats">
        <div class="stat"><b>12.4k</b><span>Tickets issued</span></div>
        <div class="stat"><b>98%</b><span>Uptime</span></div>
        <div class="stat"><b>24/7</b><span>Patrol ready</span></div>
      </div>
    </div>
    <div style="opacity:.7;font-size:12px;position:relative;z-index:2">&copy; <?= date('Y') ?> PakTraffic TVMS</div>
  </aside>

  <section class="auth-card-wrap">
    <div class="auth-card fade-up">
      <h2>Welcome back</h2>
      <p class="lead">Sign in to your PakTraffic TVMS account.</p>
      <?php if($err): ?><div class="alert alert-danger py-2"><i class="bi bi-exclamation-triangle"></i> <?= e($err) ?></div><?php endif; ?>

      <form method="post" autocomplete="on">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">

        <label class="form-label">Sign in as</label>
        <div class="role-grid mb-3">
          <label class="role-card"><input type="radio" name="role" value="admin" checked><i class="bi bi-shield-lock"></i><b>Admin</b><small>Full access</small></label>
          <label class="role-card"><input type="radio" name="role" value="officer"><i class="bi bi-person-badge"></i><b>Officer</b><small>Field duty</small></label>
          <label class="role-card"><input type="radio" name="role" value="clerk"><i class="bi bi-journal-text"></i><b>Clerk</b><small>Records</small></label>
        </div>

        <div class="mb-3">
          <label class="form-label">Email</label>
          <div class="input-with-icon">
            <i class="bi bi-envelope"></i>
            <input class="form-control" type="email" name="email" required placeholder="you@trafficpolice.gov.pk" value="admin@paktraffic.local">
          </div>
        </div>
        <div class="mb-3">
          <label class="form-label d-flex justify-content-between">Password <a href="#" tabindex="-1" style="font-size:12px">Forgot?</a></label>
          <div class="input-with-icon">
            <i class="bi bi-lock"></i>
            <input class="form-control" type="password" id="pw" name="password" required placeholder="Password" value="admin123">
            <button type="button" class="btn btn-link position-absolute" style="right:4px;top:4px;color:var(--muted)" data-toggle-pw data-target="#pw"><i class="bi bi-eye"></i></button>
          </div>
        </div>

        <button class="btn btn-grad mt-2"><i class="bi bi-box-arrow-in-right"></i> Sign in</button>
      </form>
      <div class="auth-foot">New traffic police user? <a href="signup.php">Create an account</a></div>
    </div>
  </section>
</div>
<script src="assets/js/app.js"></script>
</body></html>
