<?php
$title='Edit violation'; require_once 'includes/header.php';
$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare('SELECT * FROM violations WHERE id=?'); $stmt->execute([$id]); $v=$stmt->fetch();
if(!$v){ flash('error','Not found'); header('Location: violations.php'); exit; }
$types=['Over Speeding','Signal Violation','Illegal Parking','One Way Violation','No Helmet','Mobile Phone Use','No Fitness Certificate','Reckless Driving','Wrong Way','Expired Driving License'];

if ($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $pdo->prepare('UPDATE violations SET plate_no=?,driver_name=?,license_no=?,violation_type=?,location=?,fine_amount=?,status=?,notes=?,violation_date=? WHERE id=?')->execute([
    strtoupper(trim($_POST['plate_no'])), trim($_POST['driver_name']), trim($_POST['license_no']),
    $_POST['violation_type'], trim($_POST['location']), (float)$_POST['fine_amount'],
    $_POST['status'], trim($_POST['notes']), $_POST['violation_date'], $id
  ]);
  flash('success','Ticket updated.'); header('Location: violations.php'); exit;
}
?>
<div class="panel fade-up" style="max-width:900px;margin:0 auto">
  <h5><i class="bi bi-pencil-square"></i> Edit ticket <span class="text-muted ms-2"><?= e($v['ticket_no']) ?></span></h5>
  <form method="post" class="row g-3">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <div class="col-md-4"><label class="form-label">Plate</label><input class="form-control" name="plate_no" value="<?= e($v['plate_no']) ?>" required></div>
    <div class="col-md-4"><label class="form-label">Date</label><input class="form-control" type="datetime-local" name="violation_date" value="<?= e(date('Y-m-d\TH:i', strtotime($v['violation_date']))) ?>"></div>
    <div class="col-md-4"><label class="form-label">Status</label>
      <select class="form-select" name="status"><?php foreach(['pending','paid','contested','cancelled'] as $s): ?><option <?= $v['status']===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select></div>
    <div class="col-md-6"><label class="form-label">Driver</label><input class="form-control" name="driver_name" value="<?= e($v['driver_name']) ?>"></div>
    <div class="col-md-6"><label class="form-label">License</label><input class="form-control" name="license_no" value="<?= e($v['license_no']) ?>"></div>
    <div class="col-md-6"><label class="form-label">Type</label>
      <select class="form-select" name="violation_type"><?php foreach($types as $t): ?><option <?= $v['violation_type']===$t?'selected':'' ?>><?= $t ?></option><?php endforeach; ?></select></div>
    <div class="col-md-3"><label class="form-label">Fine (Rs.)</label><input class="form-control" type="number" step="0.01" name="fine_amount" value="<?= e($v['fine_amount']) ?>"></div>
    <div class="col-md-3"><label class="form-label">Location</label><input class="form-control" name="location" value="<?= e($v['location']) ?>"></div>
    <div class="col-12"><label class="form-label">Notes</label><textarea class="form-control" name="notes" rows="3"><?= e($v['notes']) ?></textarea></div>
    <div class="col-12"><button class="btn btn-primary"><i class="bi bi-save"></i> Save changes</button>
      <a href="violations.php" class="btn btn-outline-light">Back</a></div>
  </form>
</div>
<?php require 'includes/footer.php'; ?>
