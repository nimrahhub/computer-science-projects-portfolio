
<?php
session_start();
if(isset($_SESSION['user'])){
    header("Location: dashboard.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Restaurant Management System</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">

</head>

<body class="d-flex justify-content-center align-items-center">

<div class="card p-5 text-center" style="width:450px;">

<h2 class="mb-4">Restaurant Management System</h2>

<a href="signup.php" class="btn btn-warning mb-3">Signup</a>

<a href="login.php" class="btn btn-dark">Login</a>

</div>

</body>
</html>
