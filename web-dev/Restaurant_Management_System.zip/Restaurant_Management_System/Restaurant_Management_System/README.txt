
RESTAURANT MANAGEMENT SYSTEM

HOW TO RUN:
1. Open XAMPP
2. Start Apache and MySQL
3. Copy this folder into:
   C:/xampp/htdocs/

4. Open phpMyAdmin:
   http://localhost/phpmyadmin

5. Create database:
   restaurant_management

6. Import:
   database.sql

7. Open in browser:
   http://localhost/Restaurant_Management_System

FEATURES:
- User Signup/Login
- Session Authentication
- Add Food Orders
- View Orders
- Delete Orders
- Bootstrap Responsive Design
