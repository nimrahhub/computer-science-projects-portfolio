
function confirmDelete(){
    return confirm("Delete this order?");
}
