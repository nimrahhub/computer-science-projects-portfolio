
<?php
$conn = new mysqli("localhost","root","","restaurant_management");

if($conn->connect_error){
    die("Connection Failed");
}
?>
