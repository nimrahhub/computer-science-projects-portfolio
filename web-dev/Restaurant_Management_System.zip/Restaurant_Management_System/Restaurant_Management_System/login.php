
<?php
session_start();
include 'db.php';

if(isset($_POST['login'])){

$email=$_POST['email'];
$password=$_POST['password'];

$sql="SELECT * FROM users WHERE email='$email'";
$result=$conn->query($sql);

if($result->num_rows>0){

$row=$result->fetch_assoc();

if(password_verify($password,$row['password'])){

$_SESSION['user']=$row['fullname'];

header("Location: dashboard.php");

}else{
echo "<script>alert('Wrong Password');</script>";
}

}else{
echo "<script>alert('User Not Found');</script>";
}
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">

</head>

<body class="d-flex justify-content-center align-items-center">

<div class="card p-4" style="width:450px;">

<h2 class="text-center mb-4">Login</h2>

<form method="POST">

<input type="email" name="email" class="form-control mb-3" placeholder="Email" required>

<input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

<button type="submit" name="login" class="btn btn-dark w-100">Login</button>

</form>

<p class="mt-3 text-center">
No account?
<a href="signup.php">Signup</a>
</p>

</div>

</body>
</html>
