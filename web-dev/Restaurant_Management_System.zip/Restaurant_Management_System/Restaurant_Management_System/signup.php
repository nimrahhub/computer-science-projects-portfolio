
<?php
include 'db.php';

if(isset($_POST['signup'])){

    $fullname=$_POST['fullname'];
    $email=$_POST['email'];
    $password=password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql="INSERT INTO users(fullname,email,password)
          VALUES('$fullname','$email','$password')";

    if($conn->query($sql)){
        echo "<script>alert('Signup Successful');window.location='login.php';</script>";
    }else{
        echo "<script>alert('Email Already Exists');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Signup</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">

</head>

<body class="d-flex justify-content-center align-items-center">

<div class="card p-4" style="width:450px;">

<h2 class="text-center mb-4">Signup</h2>

<form method="POST">

<input type="text" name="fullname" class="form-control mb-3" placeholder="Full Name" required>

<input type="email" name="email" class="form-control mb-3" placeholder="Email" required>

<input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

<button type="submit" name="signup" class="btn btn-warning w-100">Signup</button>

</form>

<p class="mt-3 text-center">
Already have an account?
<a href="login.php">Login</a>
</p>

</div>

</body>
</html>
