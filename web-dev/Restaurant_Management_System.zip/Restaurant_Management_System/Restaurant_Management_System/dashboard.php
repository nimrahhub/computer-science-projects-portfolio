
<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user'])){
    header("Location: login.php");
}

if(isset($_POST['add_order'])){

$customer_name=$_POST['customer_name'];
$food_item=$_POST['food_item'];
$quantity=$_POST['quantity'];
$table_number=$_POST['table_number'];
$order_status=$_POST['order_status'];
$created_by=$_SESSION['user'];

$sql="INSERT INTO orders(customer_name,food_item,quantity,table_number,order_status,created_by)
VALUES('$customer_name','$food_item','$quantity','$table_number','$order_status','$created_by')";

$conn->query($sql);
}

if(isset($_GET['delete'])){
$id=$_GET['delete'];
$conn->query("DELETE FROM orders WHERE id=$id");
}

$orders=$conn->query("SELECT * FROM orders ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>

<title>Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
<script src="script.js"></script>

</head>

<body>

<nav class="navbar navbar-dark bg-dark p-3">

<div class="container-fluid">

<span class="navbar-brand">
Welcome, <?php echo $_SESSION['user']; ?>
</span>

<a href="logout.php" class="btn btn-danger">Logout</a>

</div>

</nav>

<div class="container mt-5">

<div class="card p-4 mb-4">

<h3>Add Food Order</h3>

<form method="POST">

<input type="text" name="customer_name" class="form-control mb-3" placeholder="Customer Name" required>

<input type="text" name="food_item" class="form-control mb-3" placeholder="Food Item" required>

<input type="number" name="quantity" class="form-control mb-3" placeholder="Quantity" required>

<input type="number" name="table_number" class="form-control mb-3" placeholder="Table Number" required>

<select name="order_status" class="form-control mb-3">
<option>Pending</option>
<option>Preparing</option>
<option>Completed</option>
</select>

<button type="submit" name="add_order" class="btn btn-warning">
Add Order
</button>

</form>

</div>

<div class="table-box">

<h3 class="mb-4">All Orders</h3>

<table class="table table-bordered table-hover">

<tr>
<th>ID</th>
<th>Customer</th>
<th>Food</th>
<th>Qty</th>
<th>Table</th>
<th>Status</th>
<th>Created By</th>
<th>Action</th>
</tr>

<?php while($row=$orders->fetch_assoc()){ ?>

<tr>

<td><?php echo $row['id']; ?></td>
<td><?php echo $row['customer_name']; ?></td>
<td><?php echo $row['food_item']; ?></td>
<td><?php echo $row['quantity']; ?></td>
<td><?php echo $row['table_number']; ?></td>
<td><?php echo $row['order_status']; ?></td>
<td><?php echo $row['created_by']; ?></td>

<td>
<a href="?delete=<?php echo $row['id']; ?>"
onclick="return confirmDelete()"
class="btn btn-danger btn-sm">
Delete
</a>
</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</body>
</html>
